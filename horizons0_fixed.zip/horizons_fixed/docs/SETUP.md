# Horizon Setup Guide

## Environment Variables
Create a `.env` file based on `.env.example` and fill in your actual Supabase credentials:
```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

## Database Migration
1. Open Supabase SQL Editor.
2. Copy and paste the SQL from `migrations/001_add_is_super_admin_and_indexes.sql`.
3. Run it to update your schema and fix sequence errors.

## Security Reminder
- Never commit `.env` or Supabase keys to version control.
- Rotate old keys if previously exposed.
