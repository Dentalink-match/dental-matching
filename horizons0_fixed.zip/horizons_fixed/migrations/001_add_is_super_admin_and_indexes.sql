-- Add missing column for super admin and indexes
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS is_super_admin boolean DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_users_is_super_admin ON public.users(is_super_admin);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_id ON public.appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON public.appointments(patient_id);

-- Fix COALESCE type mismatch for 'cases' table id sequence
SELECT setval(
  pg_get_serial_sequence('cases', 'id'),
  COALESCE(MAX(id)::bigint, 0) + 1,
  false
) FROM cases;
